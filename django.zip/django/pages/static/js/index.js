//<script src="{% static 'js/index.js' %}"></script>
let a=5;
console.log(a);